
package VehicleLend;
 import hib.dto.SignupInformation;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.Transaction;
import org.hibernate.Session;
import javax.swing.JOptionPane;

public class VehicleLend {public static void main(String[] args) {
        
        Configuration c1 =new Configuration();
        Configuration c2=c1.configure();
        SessionFactory sf=c2.buildSessionFactory();
        Session session=sf.openSession();
        Transaction tx = session.beginTransaction();
       
        int contactNo=Integer.parseInt(JOptionPane.showInputDialog("Enter contactNo"));
        String name = JOptionPane.showInputDialog("Enter your Name");
        String userId=JOptionPane.showInputDialog("Enter your user Id");
        String password=JOptionPane.showInputDialog("Enter your Password");
        String confirmPassword = JOptionPane.showInputDialog("Ente confirm Password Here");
        String emailId=JOptionPane.showInputDialog("Enter email here");
        String address = JOptionPane.showInputDialog("Enter address");
        int pin =Integer.parseInt(JOptionPane.showInputDialog("Enter pin"));
        int aNo =Integer.parseInt(JOptionPane.showInputDialog("Enter addharNO"));
    SignupInformation si=new SignupInformation(contactNo, name, userId, address, aNo, emailId, password, confirmPassword);
        session.save(si);
        tx.commit();
        session.close();
        System.out.println("record inserted ");
    }
}