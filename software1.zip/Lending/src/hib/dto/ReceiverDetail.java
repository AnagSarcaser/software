
package hib.dto;


public class ReceiverDetail {
    private int contactNo;
    private String vehicleType;
    private int forDays;
    private String address;
    private String name;
    private long addharNo;
    private int pin;

    public ReceiverDetail() {
    }

    public ReceiverDetail(int contactNo, String vehicleType, int forDays, String address, String name, long addharNo, int pin) {
        this.contactNo = contactNo;
        this.vehicleType = vehicleType;
        this.forDays = forDays;
        this.address = address;
        this.name = name;
        this.addharNo = addharNo;
        this.pin = pin;
    }
 

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public int getForDays() {
        return forDays;
    }

    public void setForDays(int forDays) {
        this.forDays = forDays;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getPin() {
        return pin;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public int getContactNo() {
        return contactNo;
    }

    public void setContactNo(int contactNo) {
        this.contactNo = contactNo;
    }

    public String getname() {
        return name;
    }

    public void setname(String name) {
        this.name = name;
    }

    public long getAddharNo() {
        return addharNo;
    }

    public void setAddharNo(long addharNo) {
        this.addharNo = addharNo;
    }
    
}
