package hib.dto;

public class LenderDetail{
private String vehicleNO;
private String userId;
private String name;
private String vehicleModel;
private int rent;
private String condition;
private String selfstart;
private String vehicleType;
private String fuelType;
private String address;
private int pin;
private int contactNo;

    public String getSelfstart() {
        return selfstart;
    }

    public String getName() {
        return name;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }



    public LenderDetail() {
    }

    public LenderDetail(String vehicleNO, String userId, String name, String vehicleModel, int rent, String condition, String selfstart, String vehicleType, String fuelType, String address, int pin, int contactNo) {
        this.vehicleNO = vehicleNO;
        this.userId = userId;
        this.name = name;
        this.vehicleModel = vehicleModel;
        this.rent = rent;
        this.condition = condition;
        this.selfstart = selfstart;
        this.vehicleType = vehicleType;
        this.fuelType = fuelType;
        this.address = address;
        this.pin = pin;
        this.contactNo = contactNo;
    }

    
    public String getVehicleModel() {
        return vehicleModel;
    }

    public void setVehicleModel(String vehicleModel) {
        this.vehicleModel = vehicleModel;
    }

    public String getVehicleNO() {
        return vehicleNO;
    }

    public void setVehicleNO(String vehicleNO) {
        this.vehicleNO = vehicleNO;
    }

    public int getRent() {
        return rent;
    }

    public void setRent(int rent) {
        this.rent = rent;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    


    public String Selfstart() {
        return selfstart;
    }

    public void setSelfstart(String selfstart) {
        this.selfstart = selfstart;
    }

    public String getVechileType() {
        return vehicleType;
    }

    public void setVechileType(String vechileType) {
        this.vehicleType = vechileType;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getname() {
        return name;
    }

    public void setname(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getPin() {
        return pin;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public int getContactNo() {
        return contactNo;
    }

    public void setContactNo(int contactNo) {
        this.contactNo = contactNo;
    }

}
