
package hib.dto;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;


public class SignupRestriction {
       public static void main(String...args){
  
       SessionFactory sf=new Configuration().configure().buildSessionFactory();
       Session session=sf.openSession();
    
       Criteria q=session.createCriteria(SignupInformation.class);
    // q.add(Restrictions.eq("name","dhruv"));
    // q.add(Restrictions.or(Restrictions.eq("name","dhruv"),Restrictions.eq("userId","dhruv")));
    q.add(Restrictions.like("name","d%"));   
    q.add(Restrictions.like("name","%d%"));
    q.add(Restrictions.like("name","%d"));
    List<SignupInformation> si1=q.list();
       if(si1==null){
           System.out.println("no record found");
          }
       else{
       for(SignupInformation si : si1){
           System.out.println(si.getAddharNo()+" "+si.getAddress()+" "+si.getEmailId());
           }
        }
       session.close();
       
   }
}

