
package hib.dto;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
public class SignupProjection {
        public static void main(String...args){
  
       SessionFactory sf=new Configuration().configure().buildSessionFactory();
       Session session=sf.openSession();
    
       //Criteria q=session.createCriteria(SignupInformation.class);
       //q.setFirstResult(1);
     //  q.setMaxResults(1);
   // List<SignupInformation> si1=q.list();
       Criteria q=session.createCriteria(SignupInformation.class);
    ProjectionList pl=Projections.projectionList();
    //pl.add(Projections.property("name"));
    //pl.add(Projections.property("emailId"));
    //pl.add(Projections.sum("emailId"));
    //pl.add(Projections.max("emailId"));
    //pl.add(Projections.min("emailId"));
   // pl.add(Projections.count("emailId"));
  //  pl.add(Projections.countDistinct("emailId"));
    q.setProjection(pl);
   List<Object[]> si1=q.list();
    
    if(si1==null){
           System.out.println("no record found");
          }
       else{
       for(Object si[] : si1){
           System.out.println(si[0]+" "+si[1]);
           }
        }
       session.close();
       
   }
}



