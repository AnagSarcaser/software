
package hib.dto;

import java.util.Scanner;
import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class SignupUpdate {
        public static void main(String[] args)
    {
     SessionFactory sf=new Configuration().configure().buildSessionFactory();
    Session session=sf.openSession();
    Transaction tx=session.beginTransaction();
    
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter contactNo to delete the record");
    int contactNo=sc.nextInt();
    
    SignupInformation si=(SignupInformation)session.get(SignupInformation.class,contactNo);
     //select*from tablename where colname=?
   if (si==null)
   {
    System.out.println("no record found to update");
   }
   else
    {
       System.out.println("-----MENU----");
       System.out.println("What do you wanna update!!!");
       System.out.println("1,name");
       System.out.println("2,userId");
       System.out.println("3,address");
       System.out.println("4,addharNo");
       System.out.println("5,emailId");
       System.out.println("6,password");      
       System.out.println("7,contactNo");
       int choice=sc.nextInt();
       switch(choice)
        {
           case 1:
               System.out.println("Enter new name");
               String uName=sc.next();
               si.setName(uName);
               session.update(si);
               tx.commit();
               System.out.println("name updated");
               break;
               
               
               
          case 2:
               System.out.println("Enter new userId");
               String uUserId=sc.next();
               si.setUserId(uUserId);
               session.update(si);
               tx.commit();
               System.out.println("userId updated");
               break;
               
               
          case 3:
               System.out.println("Enter new address");
               String uAddress=sc.next();
               si.setAddress(uAddress);                                                                                                                                                                                                
               session.update(si);
               tx.commit();
               System.out.println("address updated");
               break;
               
               
               
          case 4:
               System.out.println("Enter new addharNo");
            long uAddharNo=sc.nextLong();
               si.setAddharNo(uAddharNo);
               session.update(si);
               tx.commit();
               System.out.println("addharNo updated");
               break;
               
               
               
         case 5:
               System.out.println("Enter new emailId");
               String uEmailId=sc.next();
               si.setEmailId(uEmailId);
               session.update(si);
               tx.commit();
               System.out.println("emailId updated");
               break;
               
               
               
         case 6:
               System.out.println("Enter new password");
               String uPassword=sc.next();
               si.setPassword(uPassword);
               session.update(si);
               tx.commit();
               System.out.println("password updated");
               break;
               
        
               
        case 7:
               System.out.println("Enter new contactNo");
               int uContactNo=sc.nextInt();
               si.setContactNo(uContactNo);
               session.update(si);
               tx.commit();
               System.out.println("contactNo updated");
               break;       
               
       }
    }
   session.close();
   }
}        
   
   