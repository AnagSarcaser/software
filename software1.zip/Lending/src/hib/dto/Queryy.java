
package hib.dto;

public class Queryy {
     private String userID;
     private String description;

    public Queryy() {
    }

    public Queryy(String userID, String description) {
        this.userID = userID;
        this.description = description;
    }
     

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
