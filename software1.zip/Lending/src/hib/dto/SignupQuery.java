
package hib.dto;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class SignupQuery {
   public static void main(String...args){
  
       SessionFactory sf=new Configuration().configure().buildSessionFactory();
       Session session=sf.openSession();
      Query q= session.createQuery("from SignupInformation");
       //select*from tablename
       
       List<SignupInformation> si1=q.list();
       if(si1==null){
           System.out.println("no record found");
          }
       else{
       for(SignupInformation si : si1){
           System.out.println(si.getAddharNo()+" "+si.getAddress()+" "+si.getEmailId());
           }
        }
       session.close();
       
   }
}