
package hib.dto;
import java.util.Scanner;
import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ReceiverUpdate {
            public static void main(String[] args)
    {
     SessionFactory sf=new Configuration().configure().buildSessionFactory();
    Session session=sf.openSession();
    Transaction tx=session.beginTransaction();
    
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter contactNo to update the record");
    int contactNo=sc.nextInt();
    
    ReceiverDetail rd=(ReceiverDetail)session.get(ReceiverDetail.class,contactNo);
     //select*from tablename where colname=?
   if (rd==null)
   {
    System.out.println("no record found to update");
   }
   else
    {
       System.out.println("-----MENU----");
       System.out.println("What do you wanna update!!!");
       System.out.println("1,vehicleType");
       System.out.println("2,forDays");
       System.out.println("3,address");
       System.out.println("4,addharNo");
       System.out.println("5,name");
       System.out.println("6,contactNo");
       System.out.println("7,pin");
       int choice=sc.nextInt();
       switch(choice)
        {
           case 1:
               System.out.println("Enter new vehicleType");
               String uVehicleType=sc.next();
               rd.setVehicleType(uVehicleType);
               session.update(rd);
               tx.commit();
               System.out.println("vehicleType updated");
               break;
               
               
               
          case 2:
               System.out.println("Enter new forDays");
               int uForDays=sc.nextInt();
               rd.setForDays(uForDays);
               session.update(rd);
               tx.commit();
               System.out.println("forDays updated");
               break;
               
               
          case 3:
               System.out.println("Enter new address");
               String uAddress=sc.next();
              rd.setAddress(uAddress);                                                                                                                                                                                                
               session.update(rd);
               tx.commit();
               System.out.println("address updated");
               break;
               
               
               
          case 4:
               System.out.println("Enter new addharNo");
               long uAddharNo=sc.nextLong();
               rd.setAddharNo(uAddharNo);
               session.update(rd);
               tx.commit();
               System.out.println("addharNo updated");
               break;
               
               
               
         case 5:
               System.out.println("Enter new name");
               String uName=sc.next();
               rd.setname(uName);
               session.update(rd);
               tx.commit();
               System.out.println("emailId updated");
               break;
               
                        
        case 6:
               System.out.println("Enter new contactNo");
               int uContactNo=sc.nextInt();
               rd.setContactNo(uContactNo);
               session.update(rd);
               tx.commit();
               System.out.println("contactNo updated");
               break;       
               
               
                case 7:
               System.out.println("Enter new password");
               int uPin=sc.nextInt();
               rd.setPin(uPin);
               session.update(rd);
               tx.commit();
               System.out.println("password updated");
               break;
       }
    }
   session.close();
   }
}        
  

