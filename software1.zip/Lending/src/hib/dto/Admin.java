/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hib.dto;

/**
 *
 * @author dell
 */
public class Admin {
    private String adminId;
    private String password;
    private String apost;

    public void setPassword(String password) {
        this.password = password;
    }

    public Admin() {
    }

    public Admin(String adminId, String password, String apost) {
        this.adminId = adminId;
        this.password = password;
        this.apost = apost;
    }

    public String getAdminId() {
        return adminId;
    }

    public void setAdminId(String adminId) {
        this.adminId = adminId;
    }

    public String getPassword() {
        return password;
    }

    public void setPasssword(String passsword) {
        this.password = passsword;
    }

    public String getApost() {
        return apost;
    }

    public void setApost(String apost) {
        this.apost = apost;
    }
    
}
