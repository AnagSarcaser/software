
package hib.dto;
import java.util.Scanner;
import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class QueryUpdate {
               public static void main(String[] args)
    {
     SessionFactory sf=new Configuration().configure().buildSessionFactory();
    Session session=sf.openSession();
    Transaction tx=session.beginTransaction();
    
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter userId to update the record");
    String userId=sc.next();
    
    Queryy qu=(Queryy)session.get(Queryy.class,userId);
     //select*from tablename where colname=?
   if (qu==null)
   {
    System.out.println("no record found to update");
   }
   else
    {
       System.out.println("-----MENU----");
       System.out.println("What do you wanna update!!!");
       System.out.println("1,userId");
       System.out.println("2,description");

       int choice=sc.nextInt();
       switch(choice)
        {
           case 1:
               System.out.println("Enter new userId");
               String uUserId=sc.next();
               qu.setUserID(uUserId);
               session.update(qu);
               tx.commit();
               System.out.println("userId updated");
               break;
          
               
           case 2:
               System.out.println("Enter new description");
               String uDescription=sc.next();
               qu.setDescription(uDescription);
               session.update(qu);
               tx.commit();
               System.out.println("Description updated");
               break;     
               
               
          
       }
    }
   session.close();
   }
}
