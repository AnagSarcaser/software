
package hib.dto;


public class SignupInformation {
private int contactNo;
private String name;
private String userId;
private String address;
private long addharNo;
private String emailId;
private String password;
private String confirmPassword;

    public SignupInformation() {
    }


    public SignupInformation(int contactNo, String name, String userId, String address, long addharNo, String emailId, String password, String confirmPassword) 
    {
        this.contactNo = contactNo;
        this.name = name;
        this.userId = userId;
        this.address = address;
        this.addharNo = addharNo;
        this.emailId = emailId;
        this.password = password;
        this.confirmPassword = confirmPassword;
    }

 

    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getContactNo() {
        return contactNo;
    }

    public void setContactNo(int contactNo) {
        this.contactNo = contactNo;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public long getAddharNo() {
        return addharNo;
    }

    public void setAddharNo(long addharNo) {
        this.addharNo = addharNo;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

}
